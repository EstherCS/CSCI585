const spiro = [];
for (let t = 0.00; t < 16 * Math.PI; t += 0.1) 
{
    const spiroPoint = spirograph(t);
    spiro.push(spiroPoint);
    console.log(`${spiroPoint.long},${spiroPoint.lat},100`);
}

function spirograph(t, R = 8, r = 1, a = 4, Bovard = { lat: 34.020835, long: -118.285547 }, scale = 0.001) {
    return {
        lat: Bovard.lat + scale * ((R + r) * Math.cos((r / R) * t) - a * Math.cos((1 + r / R) * t)),
        long: Bovard.long + scale * ((R + r) * Math.sin((r / R) * t) - a * Math.sin((1 + r / R) * t))
    }
}